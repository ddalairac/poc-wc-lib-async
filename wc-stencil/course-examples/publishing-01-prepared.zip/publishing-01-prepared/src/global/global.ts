export const AV_API_KEY = 'YOUR_KEY_HERE';
